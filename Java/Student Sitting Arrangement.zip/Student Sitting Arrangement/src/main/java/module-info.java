module com.example.kunjesh_final_assignment {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.kunjesh_final_assignment to javafx.fxml;
    exports com.example.kunjesh_final_assignment;
}