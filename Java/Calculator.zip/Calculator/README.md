# **Calculator GUI**

## **Introduction**

In this Project, I have created a GUI of Calculator.

It's just an GUI. Calculator is not working at this moment.

## **Programming Languages and Technologies used**

- [x] Java
- [x] SceneBuilder
- [x] JetBrains IntelliJ
- [x] Git

## **Concepts Used**

> Containers (AnchorPane, BorderPane, Button, Label etc.)
>
> Some Formatting (color, font-size, height, width, alignment etc.)

## **Resources**

1. College Notes

## **GUI Screenshots**

<div align="center"><h3>Running HelloApplication.java file and displaying Output</h3></div><hr> 

<div align="center">

![GUI](./images/SS.png)

</div>

# <div align="center">**A Big Thank You!**</div>
