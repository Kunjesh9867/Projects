package com.example.calculator;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

/*
Name = Kunjesh Ramani
Student Number = 200515106
 */

public class Calculator {


}
